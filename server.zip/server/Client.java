import java.io.*;
import java.net.*;
import java.nio.file.Files;
import java.text.DecimalFormat;


public class Client extends Thread {

	byte[] gpx;
	String host;

	Client(byte[] gpx, String host) {
		this.gpx = gpx;
		this.host = host;
	}

	public void run() {
		ObjectOutputStream out= null ;
		ObjectInputStream in = null ;
		Socket requestSocket= null ;

		try {
			/* Create socket for contacting the server on port 4321*/
			requestSocket = new Socket(host,4321);
			/* Create the streams to send and receive data from server */
			out = new ObjectOutputStream(requestSocket.getOutputStream());
			in = new ObjectInputStream(requestSocket.getInputStream());
			/* Write the two integers */
			out.writeObject(gpx);
			out.flush();
			/* Print the received result from server */
			ResultsOfRoute result = (ResultsOfRoute)in.readObject();
			writeToFile(result);


		} catch (UnknownHostException unknownHost) {
			System.err.println("You are trying to connect to an unknown host!");
		}catch(ClassNotFoundException e){
			throw new RuntimeException(e);
		} catch (IOException ioException) {
			ioException.printStackTrace();
		} finally {
			try {
				in.close();	out.close();
				requestSocket.close();
			} catch (IOException ioException) {
				ioException.printStackTrace();
			}
		}
	}


	public static void main(String[] args) throws Exception { //new client with argument the server's IP
		String host = "localhost";	
		if (args.length>0){
			host = args[0];
        }

		File file;
		byte[] content;
        
		file = new File("gpxs\\route1.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();

		file = new File("gpxs\\route2.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();

		file = new File("gpxs\\route3.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();

		file = new File("gpxs\\route4.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();

		file = new File("gpxs\\route5.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();

		file = new File("gpxs\\route6.gpx");
		content = Files.readAllBytes(file.toPath());
		new Client(content,host).start();
	}

	public void writeToFile(ResultsOfRoute results){
	
		DecimalFormat df = new DecimalFormat("#.##");
		String time = df.format(results.getTime());
		String distance =  df.format(results.getDistance());
		String elevation =  df.format(results.getElevation());
		String speed =  df.format(results.getSpeed());
		String creator = results.getCreator();

		try (BufferedWriter writer = new BufferedWriter(new FileWriter("users\\"+creator+"_"+results.getNumberOfRoute()+"_Results.txt"))){
			writer.write("User: "+creator);
			writer.write("\n");
			writer.write("Time spent: "+time+" s.");
			writer.write("\n");
			writer.write("Distance covered: "+distance+" Km.");
			writer.write("\n");
			writer.write("Elevation climbed: "+elevation+" m.");
			writer.write("\n");
			writer.write("Average speed: "+speed+" m/s.");
			writer.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

   }
}