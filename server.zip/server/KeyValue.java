import java.io.Serializable;
import java.util.*;

public class KeyValue implements Serializable {
    private  int key;
    private  String value;
    private ArrayList<String> segments;

    public KeyValue(int key, String value, ArrayList<String> segments) { // key value and the segments
        this.segments = segments;
        this.key = key;
        this.value = value;
    }

    public void setKey(int key){
        this.key = key;
    }

    public void setValue(String value){
        this.value = value;
    }

    public int getKey() {
        return key;
    }

    public String getValue() {
        return value;
    }

    
    public ArrayList<String> getSegments() {
        return segments;
    }

    public void setSegments(ArrayList<String> segments) {
        this.segments = segments;
    }

}
