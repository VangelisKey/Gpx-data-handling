import java.io.*;
import java.net.*;


public class ActionsForWorkers extends Thread {
	ObjectInputStream in;
	ObjectOutputStream out;
	public ActionsForWorkers(Socket connection) {
		try {
			out = new ObjectOutputStream(connection.getOutputStream());
			in = new ObjectInputStream(connection.getInputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {

		try {
			KeyValue new_kv = (KeyValue) in.readObject(); // get Key and Value from Master

			Worker worker =	new Worker(new_kv.getKey(),new_kv.getValue(),new_kv.getSegments());
			Thread worker_thread = new Thread(worker);
			worker_thread.run();//(Runnable) start worker with key and value
			try{
				worker_thread.join();
			}catch(InterruptedException e){
				System.out.println("Could not join the worker.");
			}
			out.writeObject(worker.getResult());
			out.flush(); //send Intermediate results to Master

		} catch (IOException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			throw new RuntimeException(e);
		} finally {
			try {
				in.close();
				out.close();
			} catch (IOException ioException) {
				ioException.printStackTrace();
			}
		}
	}
}