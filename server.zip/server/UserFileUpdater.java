import java.text.DecimalFormat;
import java.io.*;
public class UserFileUpdater{
    private boolean isWriting = false;
    private boolean isReading = false;
    
    UserFileUpdater(){
    }
 
    public void writeUserFile(String file_name, int number_of_routes,double total_distance, double total_time, double total_elevation, double average_distance, double average_time, double average_elevation){
        synchronized(this) {
            while(isWriting) {
                try{
                    wait();
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
            isWriting = true;
        }
        DecimalFormat df = new DecimalFormat("#.##");
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file_name))){
            writer.write("Number of routes: "+number_of_routes);
            writer.write("\n");
            writer.write("Total Distance: "+df.format(total_distance)+" Km");
            writer.write("\n");
            writer.write("Total Time: "+df.format(total_time)+" s");
            writer.write("\n");
            writer.write("Total Elevation: "+df.format(total_elevation)+" m");
            writer.write("\n");
            writer.write("Average Time: "+df.format(average_time)+" s");
            writer.write("\n");
            writer.write("Average Distance: "+df.format(average_distance)+" Km");
            writer.write("\n");
            writer.write("Average Elevation: "+df.format(average_elevation)+" m");
            writer.write("\n");
            double average_speed = 0;
            if(total_time>0){
                average_speed = 1000*total_distance/total_time;
            }
            writer.write("Average Speed: "+df.format(average_speed)+" m/s");
            writer.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        synchronized(this){
            isWriting = false;
            notifyAll();
        }
    }
    public String[] readOnly(String file_name){
        String user_total_distance = "";
        String user_total_elevation = "";
        String user_total_time = "";
        String user_number_from_string = "";
        try {
            BufferedReader user_reader = new BufferedReader(new FileReader(file_name));
            String line;
            while ((line = user_reader.readLine()) != null) {
                if(line.contains("Total Distance")){
                    user_number_from_string = line.replace("Total Distance: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" Km", ""); 
                    user_total_distance = user_number_from_string;
                }
                if(line.contains("Total Time")){
                    user_number_from_string = line.replace("Total Time: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" s", ""); 
                    user_total_time = user_number_from_string;
                }
                if(line.contains("Total Elevation")){
                    user_number_from_string = line.replace("Total Elevation: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" m", ""); 
                    user_total_elevation = user_number_from_string;
                }
            }
            user_reader.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }
        String[] results ={user_total_distance,user_total_time,user_total_elevation};
        return results;
    }
    public int readFromFile(String file_name, ResultsOfRoute results){
        synchronized(this) {
            while(isReading) {
                try{
                    wait();
                } catch (InterruptedException e){
                    e.printStackTrace();
                }
            }
            isReading = true;
        }

        int user_number_of_routes = 0;
        double user_total_distance = 0;
        double user_total_elevation = 0;
        double user_total_time = 0;
        double user_average_time = 0;
        double user_average_distance = 0;
        double user_average_elevation = 0;
        String user_number_from_string = "";
        try {
            BufferedReader user_reader = new BufferedReader(new FileReader(file_name));
            String line;
            while ((line = user_reader.readLine()) != null) {
                if(line.contains("Number of routes")){
                    user_number_from_string = line.replace("Number of routes: ", ""); 
                    user_number_of_routes = Integer.parseInt(user_number_from_string);
                }
                if(line.contains("Total Distance")){
                    user_number_from_string = line.replace("Total Distance: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" Km", ""); 
                    user_total_distance = Double.parseDouble(user_number_from_string);
                }
                if(line.contains("Total Time")){
                    user_number_from_string = line.replace("Total Time: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" s", ""); 
                    user_total_time = Double.parseDouble(user_number_from_string);
                }
                if(line.contains("Total Elevation")){
                    user_number_from_string = line.replace("Total Elevation: ", ""); 
                    user_number_from_string = user_number_from_string.replace(" m", ""); 
                    user_total_elevation = Double.parseDouble(user_number_from_string);
                }
            }
            user_reader.close();
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

        user_number_of_routes+=1;
        user_total_distance+=results.getDistance();
        user_total_time+=results.getTime();
        user_total_elevation+=results.getElevation();
        user_average_distance = user_total_distance/user_number_of_routes;
        user_average_time = user_total_time/user_number_of_routes;
        user_average_elevation = user_total_elevation/user_number_of_routes;
        
        writeUserFile(file_name, user_number_of_routes, user_total_distance, user_total_time, user_total_elevation, user_average_distance, user_average_time,  user_average_elevation);
        synchronized(this){
            isReading = false;
            notifyAll();
        }
        return user_number_of_routes; 
    }
}
