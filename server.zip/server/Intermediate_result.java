import java.io.Serializable;
import java.util.ArrayList;

public class Intermediate_result implements Serializable {
    private int key;
    private String value;
    private double distance;
    private double elevation;
    private double average_speed;
    private long total_time;
    private ArrayList<ArrayList<Integer>> equal_waypoints;
    private int position;
   
   
    Intermediate_result(int key,double distance,double elevation,double average_speed,long total_time,int position, ArrayList<ArrayList<Integer>> equal_waypoints){
        this.equal_waypoints = equal_waypoints;
        this.key = key;
        this.distance = distance;
        this.elevation = elevation;
        this.average_speed = average_speed;
        this.total_time = total_time;
        this.position = position;
    }
 
    public int getPosition() {
        return position;
    }

    public void setPosition(int position) {
        this.position = position;
    }
    public int getKey(){
        return key;
    }

    public String getValue(){
        return value;
    }

    public void setKey(int key){
        this.key = key;
    }

    public void setValue(String value){
        this.value = value;
    }

    public double getDistance() {
        return distance;
    }
    public void setDistance(double distance) {
        this.distance = distance;
    }
    public double getElevation() {
        return elevation;
    }
    public void setElevation(double elevation) {
        this.elevation = elevation;
    }
    public double getAverage_speed() {
        return average_speed;
    }
    public void setAverage_speed(double average_speed) {
        this.average_speed = average_speed;
    }
    public long getTotal_time() {
        return total_time;
    }
    public void setTotal_time(long total_time) {
        this.total_time = total_time;
    }

    public ArrayList<ArrayList<Integer>> getEqual_waypoints() {
        return equal_waypoints;
    }

    public void setEqual_waypoints( ArrayList<ArrayList<Integer>> equal_waypoints) {
        this.equal_waypoints = equal_waypoints;
    }


}
