import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.ArrayList;

public class Master implements Runnable {
    static int gpx_counter = 0;
    HashMap<Integer,String> keys_values;
    ResultsOfRoute results;
    String creator;
    ArrayList<Intermediate_result> intermediate_result_list;
    HashMap<Integer,ArrayList<Intermediate_result>> lists_for_reduce = new HashMap<Integer,ArrayList<Intermediate_result>>();
    ArrayList<String> segments;
    static String worker_ip[];
    UserFileUpdater fileUpdater;


    public ResultsOfRoute getResults() {
        return results;
    }

    public void setResults(ResultsOfRoute results) {
        this.results = results;
    }

    int clump_size = 10;
    String gpx;
    KeyValue new_kv;
    static int number_of_workers;
    double total_distance = 0;
    double total_elevation = 0;
    double total_speed=0;
    double total_time = 0;
    int key_counter;

    public Master(int number){
        number_of_workers =number;
    }
    public Master(String gpx, int key_counter){
        this.gpx = gpx;
        this.key_counter = key_counter;
    }

    public static void main(String args[]){
        int number = 1;
        if (args.length>0){
            number = Integer.parseInt(args[0]);
        }
        worker_ip = new String[number];
  
        for(int i =1; i<args.length;i++){
            worker_ip[i-1] = args[i];
        }
        
        new Master(number).openServer();
    }

    /* Define the socket that receives requests */
    ServerSocket s;
    /* Define the socket that is used to handle the connection */
    Socket providerSocket;
    ServerSocket s2;
    /* Define the socket that is used to handle the connection */
    Socket providerSocket2;
    void openServer() {
        new Thread(() ->{
            try {
                /* Create Server Socket */
                s = new ServerSocket(4321);

                while (true) {
                    /* Accept the connection */
                    providerSocket = s.accept();
                    /* Handle the request */
                    gpx_counter++;
                    Thread d = new ActionsForClients(providerSocket,gpx_counter);
                    d.start();
                }

            } catch (IOException ioException) {
                ioException.printStackTrace();
            } finally {
                try {
                    providerSocket.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        }).start();

        new Thread(() ->{
            try {
                
                /* Create Server Socket */
                s2 = new ServerSocket(4322);

                while (true) {  
                    /* Accept the connection */
                    providerSocket2 = s2.accept();
                    /* Handle the request */
                    Thread d2 = new ActionsForClients2(providerSocket2);
                    d2.start();
                }

            } catch (IOException ioException) {
                ioException.printStackTrace();
            } finally {
                try {
                    providerSocket.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void run(){
        readSegments();
        fileUpdater = new UserFileUpdater();

        boolean exists = false;
        File folder = new File("users\\");
        File[] listOfFiles = folder.listFiles();
        for(int i = 0; i< listOfFiles.length;i++){
            if(listOfFiles[i].getName().equals("all_user_statistics.txt")){
                exists = true;
                break;
            }
        }
        if(!exists){
            fileUpdater.writeUserFile("users\\all_user_statistics.txt", 0,0,0,0,0,0,0);
        }
        //read user file
        parseGpxFile(gpx); 

        callWorkers();

        reduce(key_counter, lists_for_reduce.get(key_counter));
        results.setCreator(creator);
        results.setNumberOfRoute(fileUpdater.readFromFile("users\\"+creator+".txt",results)); //update user file

        fileUpdater.readFromFile("users\\all_user_statistics.txt",results); //update total user statistics
    }

    public void parseGpxFile(String gpx){    
        boolean exists = false;
        File folder = new File("users\\");
        File[] listOfFiles = folder.listFiles();
        intermediate_result_list = new ArrayList<Intermediate_result>();
        lists_for_reduce.put(key_counter, intermediate_result_list);
        results = new ResultsOfRoute();
        keys_values = new HashMap<Integer,String>();
        creator = null;

        new_kv = new KeyValue(0, "",segments);
        try (BufferedReader reader = new BufferedReader(new StringReader(gpx))) {
            String line;
            int line_counter = 0;
            int key = key_counter*100;
            String value = "";
            String value_for_next = "";
   
            while ((line = reader.readLine()) != null) {
                if((clump_size * 4 ) - ((line_counter-2) % (clump_size*4)) < 5 ){
                    value_for_next+=line;
                }
                if (line_counter>1){ //after xml and gpx lines    |<?xml version="1.0"?>|  |<gpx version="1.1" creator="user1">|
                    value+=line;
                    if((line_counter-1) %  (4 * clump_size) == 0){

                        keys_values.put(key,value);
                        key++;
                        value = "";
                        value+=value_for_next;
                        value_for_next ="";
                    }
                }

                if (line.contains("<gpx")) {
                    creator = extractAttribute(line, "creator");
                    exists = false;
                    for(int i = 0; i< listOfFiles.length;i++){
                        if(listOfFiles[i].getName().equals(creator+".txt")){
                            exists = true;
                            break;
                        }
                    }
                    if(!exists){
                        fileUpdater.writeUserFile("users\\"+creator+".txt", 0,0,0,0,0,0,0);
                    }
                    
                }

                line_counter ++;
            }
            if(value!=""){
                keys_values.put(key,value);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void callWorkers() {
        int i = 0;
        for(HashMap.Entry<Integer, String> set :keys_values.entrySet()){
            KeyValue new_kv = new KeyValue(set.getKey(), set.getValue(),segments);
            ObjectOutputStream out= null ;
            ObjectInputStream in = null ;
            Socket requestSocket= null ;

            try {
                /* Create socket for contacting the server on port i+10000, 10000,10001,10002...*/
                requestSocket = new Socket(worker_ip[i],i+10000);
                /* Create the streams to send and receive data from server */
                out = new ObjectOutputStream(requestSocket.getOutputStream());
                in = new ObjectInputStream(requestSocket.getInputStream());
                /* Write the value and key */
                out.writeObject(new_kv);
                out.flush();

                Intermediate_result result = (Intermediate_result)in.readObject();
                lists_for_reduce.get(result.getKey()).add(result);

            } catch (UnknownHostException unknownHost) {
                System.err.println("You are trying to connect to an unknown host!");
            }catch(ClassNotFoundException e){
                throw new RuntimeException(e);
            } catch (IOException ioException) {
                ioException.printStackTrace();
            } finally {
                try {
                    in.close();	out.close();
                    requestSocket.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
            i = (i + 1) % number_of_workers;
        }


    }

    private void reduce(int key2, ArrayList<Intermediate_result> intermediate_results){
        int counter[] = {0,0};
        
        for(Intermediate_result result: intermediate_results){
            //for segments - incomplete
            for(int i = 0;i<segments.size();i++){
                for(int j:result.getEqual_waypoints().get(i)){
                    if(j!=-1){
                        counter[i]++;
                    }
                    
                }
            }//for segments - incomplete
            total_distance += result.getDistance();
            total_elevation += result.getElevation();
            total_time += result.getTotal_time();
        }
        total_speed = 1000*total_distance/total_time;
        results.setDistance(total_distance);
        results.setElevation(total_elevation);
        results.setTime(total_time);
        results.setSpeed(total_speed);
    }


    private static String extractAttribute(String line, String attributeName) {
        int startIndex = line.indexOf(attributeName + "=\"") + attributeName.length() + 2;
        int endIndex = line.indexOf("\"", startIndex);
        return line.substring(startIndex, endIndex);
    }


    public void readSegments(){
        segments = new ArrayList<String>();
        File folder = new File("gpxs\\");
        File[] listofFiles = folder.listFiles();
        for(File file: listofFiles){
            if(!file.getName().contains("segment")){continue;}
            String segment ="";
            
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                int line_counter = 0;

                while ((line = reader.readLine()) != null) {
                    if(line_counter>1){
                        segment+=line;
                    }
                    
                    line_counter++;
                }
               
                
            } catch (Exception e) {
                e.printStackTrace();
            }
            segments.add(segment);
        }

    }
}