import java.io.Serializable;

public class ResultsOfRoute implements Serializable{

    String creator;
    double time;
    double speed;
    double distance;
    double elevation;
    int numberOfRoute;
   
    ResultsOfRoute(){}
    ResultsOfRoute(String creator,int numberOfRoute,double time,double speed, double distance, double elevation){
        this.creator = creator;
        this.numberOfRoute = numberOfRoute;
        this.time = time;
        this.speed = speed;
        this.distance = distance;
        this.elevation = elevation;
    }

    public String getCreator() {
        return creator;
    }

    public void setCreator(String creator) {
        this.creator = creator;
    }
    public int getNumberOfRoute() {
        return numberOfRoute;
    }
    public void setNumberOfRoute(int numberOfRoute) {
        this.numberOfRoute = numberOfRoute;
    }
    public double getTime() {
        return time;
    }

    public void setTime(double time) {
        this.time = time;
    }

    public double getSpeed() {
        return speed;
    }

    public void setSpeed(double speed) {
        this.speed = speed;
    }

    public double getDistance() {
        return distance;
    }

    public void setDistance(double distance) {
        this.distance = distance;
    }

    public double getElevation() {
        return elevation;
    }

    public void setElevation(double elevation) {
        this.elevation = elevation;
    }

}