import java.io.*;
import java.net.*;

public class ActionsForClients2 extends Thread {
	ObjectInputStream in;
	ObjectOutputStream out;

	public ActionsForClients2(Socket connection) {
		
        try {
			out = new ObjectOutputStream(connection.getOutputStream());
			in = new ObjectInputStream(connection.getInputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		try {
            String name =(String) in.readObject();
            String[][] all_statistics = new String[2][];
			UserFileUpdater reader = new UserFileUpdater();
            File file = new File("users\\"+name+".txt");
            if(!file.exists()){
                String[][] error = {{"Doesn't exist"}};
                out.writeObject(error);
                out.flush();
                return;
            }
            all_statistics[0]=reader.readOnly("users\\"+name+".txt");
            all_statistics[1]=reader.readOnly("users\\all_user_statistics.txt");
            File folder = new File("users\\");
            File[] liftOfFiles = folder.listFiles();
            int user_count = liftOfFiles.length -1;
            if(user_count>0){
                all_statistics[1][0]= Double.toString(Double.parseDouble(all_statistics[1][0])/user_count);
                all_statistics[1][1]= Double.toString(Double.parseDouble(all_statistics[1][1])/user_count);
                all_statistics[1][2]= Double.toString(Double.parseDouble(all_statistics[1][2])/user_count);
            }

			out.writeObject(all_statistics); //push results to client
			out.flush();

		} catch (IOException e) {
			e.printStackTrace();
        }catch (ClassNotFoundException e){
            e.printStackTrace();

		} finally {
			try {
				in.close();
				out.close();
			} catch (IOException ioException) {
				ioException.printStackTrace();
			}
		}
	}
}