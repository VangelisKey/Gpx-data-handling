import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;

public class ActionsForClients extends Thread {
	ObjectInputStream in;
	ObjectOutputStream out;
	int gpx_counter;

	public ActionsForClients(Socket connection,int gpx_counter) {
		this.gpx_counter = gpx_counter;
		try {
			out = new ObjectOutputStream(connection.getOutputStream());
			in = new ObjectInputStream(connection.getInputStream());

		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public void run() {
		try {
			byte[] gpx_bytes = (byte[]) in.readObject(); //get gpx from client
			String gpx_contents = new String(gpx_bytes, StandardCharsets.UTF_8);

			Master new_master = new Master(gpx_contents,gpx_counter);
			Thread master_thread = new Thread(new_master);
			master_thread.run(); // (Runnable) start master with the gpx file


			try{
				master_thread.join(); //get results
			}catch(InterruptedException e){
				System.out.println("Could not join master thread");
			}
			ResultsOfRoute results = new_master.getResults();
			String[] string_results ={
				results.getCreator(),
				Integer.toString(results.getNumberOfRoute()),
				Double.toString(results.getTime()),
				Double.toString(results.getSpeed()),
				Double.toString(results.getDistance()),
				Double.toString(results.getElevation())};
			out.writeObject(string_results); //push results to client
			out.flush();

		} catch (IOException e) {
			e.printStackTrace();
		}catch(ClassNotFoundException e){
			throw new RuntimeException(e);
		} finally {
			try {
				in.close();
				out.close();
			} catch (IOException ioException) {
				ioException.printStackTrace();
			}
		}
	}
}