import java.util.*;
import java.text.*;
import java.net.*;
import java.io.*;
import java.time.Duration;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
public class Worker implements Runnable {
    int key;
    String value;
    int id;
    Intermediate_result result;
    ArrayList<String> segments;
    /* Define the socket that receives requests */
    ServerSocket s_worker;
    /* Define the socket that is used to handle the connection */
    Socket providerSocketWorker;
    void openServer() { // server for Master to connect and send key and value

        new Thread(() ->{
            try {
                /* Create Server Socket */
                s_worker = new ServerSocket(id+10000);

                while (true) {
                    /* Accept the connection */

                    providerSocketWorker = s_worker.accept();
                    /* Handle the request */
                    Thread d_worker = new ActionsForWorkers(providerSocketWorker);
                    d_worker.start();

                }

            } catch (IOException ioException) {
                ioException.printStackTrace();
            } finally {
                try {
                    providerSocketWorker.close();
                } catch (IOException ioException) {
                    ioException.printStackTrace();
                }
            }
        }).start();


    }

    public static void main(String[] args){ // new worker with argument it's ID, worker IDs start from 0
        new Worker(Integer.parseInt(args[0])).openServer();
    }
    
    @Override
    public void run(){
        map();
    }

    private void map(){
        double total_distance = 0;
        double average_speed = 0;
        double total_elevation = 0;
        long total_time = 0;
        String[] wpts = value.replaceAll("[<>]+", "<").split("<", -1);
       
        ArrayList<Wpt> chunk_waypoints = createWaypoints(wpts);

        for(int wpt_number = 0; wpt_number < chunk_waypoints.size() - 1; wpt_number++){
            double current_lat = chunk_waypoints.get(wpt_number).getLat();
            double current_lon = chunk_waypoints.get(wpt_number).getLon();
            double current_ele = chunk_waypoints.get(wpt_number).getEle();
            double next_ele = chunk_waypoints.get(wpt_number+1).getEle();
            double next_lat = chunk_waypoints.get(wpt_number+1).getLat();
            double next_lon = chunk_waypoints.get(wpt_number+1).getLon();

            total_elevation +=elevationCalc(current_ele, next_ele);
            total_distance +=distanceCalculator(current_lat, current_lon, next_lat, next_lon);

            String current_time = chunk_waypoints.get(wpt_number).getTime();
            String next_time = chunk_waypoints.get(wpt_number+1).getTime();
            total_time += timeCalculator(current_time, next_time);
        }
        if(total_time!=0){
            average_speed = total_distance/total_time;
        }else{
            average_speed=0;
        }
        ArrayList<ArrayList<Integer>> equal_waypoints = new ArrayList<ArrayList<Integer>>();
        int seg_counter = 0;
        for(String segment: segments){
            ArrayList<Wpt> segment_waypoints = createWaypoints(segment.replaceAll("[<>]+", "<").split("<", -1)); 
            equal_waypoints.add(seg_counter,isInSegment(chunk_waypoints, segment_waypoints));
        }
        
        setResult(new Intermediate_result((int)key/100, total_distance, total_elevation, average_speed, total_time,key % 100, equal_waypoints));
    }

    private ArrayList<Wpt> createWaypoints(String[] wpts){
        ArrayList<Wpt> chunk_waypoints = new ArrayList<Wpt>();
        Double lat = null;
        Double lon = null;
        Double ele = null;
        String time = null;
        for(int line = 0; line<wpts.length;line++){

            if (wpts[line].contains("wpt")&&(!wpts[line].contains("/"))) {
                lat = Double.parseDouble(extractAttribute(wpts[line], "lat"));
                lon = Double.parseDouble(extractAttribute(wpts[line], "lon"));
            }

            if (wpts[line].contains("ele")&&(!wpts[line].contains("/"))) {
                ele = Double.parseDouble(wpts[line+1].replaceAll("[^\\d.]", ""));
            }

            if (wpts[line].contains("time")&&(!wpts[line].contains("/"))) {
                try {
                    time = extractTimestamp(wpts[line+1]);
                    chunk_waypoints.add(new Wpt(lat, lon, ele, time));
                } catch (ParseException e) {
                    System.err.println("Error parsing timestamp: " + e.getMessage());
                }
            }
        }
        return chunk_waypoints;
    }

    private String extractAttribute(String line, String attributeName) {
        int startIndex = line.indexOf(attributeName + "=\"") + attributeName.length() + 2;
        int endIndex = line.indexOf("\"", startIndex);
        return line.substring(startIndex, endIndex);
    }
    private String extractTimestamp(String line) throws ParseException {
        String timestampString = line.replaceAll("<time>|</time>", "").trim();
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'");
        Date timestamp = sdf.parse(timestampString);
        return sdf.format(timestamp);
    }

    private Double elevationCalc(Double ele1, Double ele2){
        Double elevation = 0.0;
        if(ele2>ele1){elevation+=ele2-ele1;}
        return elevation;
    }


    public double distanceCalculator(double latitude_start, double longtitude_start, double latitude_finish, double longtitude_finish) {
        final double R = 6371; // Radius of the earth in km
        double dLat = Math.toRadians(latitude_finish - latitude_start);
        double dLon = Math.toRadians(longtitude_finish - longtitude_start);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) + Math.cos(Math.toRadians(latitude_start)) * Math.cos(Math.toRadians(latitude_finish)) * Math.sin(dLon/2) * Math.sin(dLon/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double distance = R * c; // Distance in km
        return distance;
    }

    private long timeCalculator(String time_start, String time_finish){
        LocalDateTime time1 = LocalDateTime.parse(time_start, DateTimeFormatter.ISO_DATE_TIME);
        LocalDateTime time2 = LocalDateTime.parse(time_finish, DateTimeFormatter.ISO_DATE_TIME);
        Duration duration = Duration.between(time1, time2);

        return duration.getSeconds();
    }

    
    private ArrayList<Integer> isInSegment(ArrayList<Wpt> chunk, ArrayList<Wpt> segment){
        ArrayList<Integer> equal_waypoints = new ArrayList<Integer>();
        
        for(Wpt waypoint: chunk){
            int segment_waypoint_counter = 0;
            for(Wpt segment_waypoint: segment){
                if(distanceCalculator(waypoint.getLat(), waypoint.getLon(), segment_waypoint.getLat(), segment_waypoint.getLon())*1000<6){
                    equal_waypoints.add(segment_waypoint_counter);
                }else{
                    equal_waypoints.add(-1);
                }
                segment_waypoint_counter++;
            }       
        }
        return equal_waypoints;
    }

    public Intermediate_result getResult() {
        return result;
    }

    public void setResult(Intermediate_result result) {
        this.result = result;
    }

    public Worker(int id){
        this.id = id;
    }
    public Worker(int key, String value, ArrayList<String> segments) {
        this.key = key;
        this.value = value;
        this.segments = segments;
    }

    public int getKey() {
        return key;
    }

    public void setKey(int key) {
        this.key = key;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }
}

