package com.example.myapplication;

import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.net.Socket;
import android.widget.Toast;


public class MyThread2 extends Thread{

    String name;
    Handler handler;

    public MyThread2(String name, Handler handler){
        this.name = name;
        this.handler = handler;
    }


    @Override
    public void run() {
        Message msg = new Message();
        Bundle bundle = new Bundle();
        String[][] result = new String[2][];

        try {
            Socket socket = new Socket("192.168.2.3", 4322);

            OutputStream outputStream = socket.getOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(outputStream);

            // Send the byte array
            oos.writeObject(name);
            oos.flush();

            InputStream inputStream = socket.getInputStream();
            ObjectInputStream ois = new ObjectInputStream(inputStream);

            // Read the deserialized object
            result = (String[][]) ois.readObject();


            socket.close();
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();

        }
        bundle.putSerializable("STATISTICS",result);
        msg.setData(bundle);
        handler.sendMessage(msg);
    }
}