package com.example.myapplication;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class RouteResultsActivity extends AppCompatActivity {
    ResultsOfRoute route_results;
    TextView distance;
    TextView time;
    TextView speed;
    TextView elevation;

    Button go_back;
    String user_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_route_results);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("ROUTE_RESULTS")) {
            route_results = (ResultsOfRoute) intent.getSerializableExtra("ROUTE_RESULTS");
        }
        if (intent != null && intent.hasExtra("USERNAME")) {
            user_name = (String) intent.getSerializableExtra("USERNAME");
        }
        distance = (TextView) findViewById(R.id.UserDistance);
        time = (TextView) findViewById(R.id.UserTime);
        speed = (TextView) findViewById(R.id.UserSpeed);
        elevation = (TextView) findViewById(R.id.UserElevation);
        go_back = (Button) findViewById(R.id.button_go_back);

        distance.setText(distance.getText()+" "+Math.round(route_results.getDistance()*100)/100.0+" Km");
        time.setText(time.getText()+" "+Math.round(route_results.getTime()*100)/100.0+" s");
        speed.setText(speed.getText()+" "+Math.round(route_results.getSpeed()*100)/100.0+" m/s");
        elevation.setText(elevation.getText()+" "+Math.round(route_results.getElevation()*100)/100.0+" m");

        go_back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("USERNAME",user_name);
                startActivity(intent);
            }
        });
    }
}
