package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.FileNotFoundException;
import android.widget.Toast;
import android.content.pm.PackageManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.activity.result.ActivityResultLauncher;

public class MainActivity extends AppCompatActivity {
    private static final String STORAGE_PERMISSION = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    private static final int STORAGE_PERMISSION_REQUEST_CODE = 1000;
    private static final int READ_REQUEST_CODE = 42;

    private ActivityResultLauncher<String> requestPermissionLauncher;
    Button btn;

    Button btn_stat;

    Handler handler;

    Handler handler_statistics;

    ResultsOfRoute route_result;

    String[][] statistics;

    EditText get_user_name;
    String user_name;

    TextView header;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //request permission
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},STORAGE_PERMISSION_REQUEST_CODE);
        }
        user_name ="";
        header = (TextView) findViewById(R.id.header_title);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("USERNAME")) {
            user_name = (String) intent.getSerializableExtra("USERNAME");
            header.setText("Welcome "+user_name+"!");
        }


        handler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                route_result = (ResultsOfRoute) message.getData().getSerializable("result");
                if(route_result.getCreator()==null){
                    Toast.makeText(MainActivity.this,"Couldn't get access to server. Try again later.",Toast.LENGTH_LONG).show();
                    return false;
                }
                Intent intent = new Intent(getApplicationContext(), RouteResultsActivity.class);
                intent.putExtra("ROUTE_RESULTS", route_result);
                intent.putExtra("USERNAME",user_name);
                startActivity(intent);
                return true;
            }
        });

        handler_statistics = new Handler(Looper.getMainLooper(), new Handler.Callback() {
            @Override
            public boolean handleMessage(@NonNull Message message) {
                statistics = (String[][]) message.getData().getSerializable("STATISTICS");
                if(statistics==null){

                    Toast.makeText(MainActivity.this,"Couldn't get access to server. Try again later.",Toast.LENGTH_LONG).show();
                    return false;
                }
                if(statistics[0][0].contains("Doesn't exist")){
                    Toast.makeText(MainActivity.this,"This username is not valid.",Toast.LENGTH_LONG).show();
                    Toast.makeText(MainActivity.this,"Make sure you have uploaded a route first.",Toast.LENGTH_LONG).show();
                    return false;
                }
                Intent intent = new Intent(getApplicationContext(), TotalStatisticsActivity.class);
                intent.putExtra("STATISTICS", statistics);
                intent.putExtra("USERNAME",user_name);
                startActivity(intent);
                return true;
            }
        });

        btn = (Button) findViewById(R.id.button);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                performFileSearch();
            }
        });

        btn_stat = (Button) findViewById(R.id.button_statistics);
        btn_stat.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(user_name==null){
                    return;
                }
                MyThread2 t2 = new MyThread2(user_name,handler_statistics);
                t2.start();
            }
        });

        get_user_name = (EditText) findViewById(R.id.user_name_input);
        get_user_name.setOnKeyListener(new View.OnKeyListener() {
            public boolean onKey(View v, int keyCode, KeyEvent event) {
                // If the event is a key-down event on the "enter" button
                if ((event.getAction() == KeyEvent.ACTION_DOWN) &&
                        (keyCode == KeyEvent.KEYCODE_ENTER)) {
                    user_name = get_user_name.getText().toString();
                    header.setText("Welcome "+user_name+"!");
                    return true;
                }
                return false;
            }
        });
    }

    private void requestStoragePermission() {
        // Check if the permission is granted
        if (ContextCompat.checkSelfPermission(this, STORAGE_PERMISSION) == PackageManager.PERMISSION_GRANTED) {
            // Permission is already granted
            // You can proceed with accessing internal storage
        } else {
            // Permission is not granted
            // Request the permission
            ActivityCompat.requestPermissions(this, new String[]{STORAGE_PERMISSION}, STORAGE_PERMISSION_REQUEST_CODE);
        }
    }

    private void performFileSearch(){
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        startActivityForResult(intent,READ_REQUEST_CODE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == READ_REQUEST_CODE && resultCode == Activity.RESULT_OK) {
            if (data != null) {
                Uri uri = data.getData();
                try{

                    byte[] fileContents = readBytesFromUri(uri);

                    MyThread t1 = new MyThread(fileContents,handler);
                    t1.start();

                } catch(FileNotFoundException e){
                    e.printStackTrace();
                } catch (IOException e){
                    e.printStackTrace();
                }

            }
        }
    }

    private byte[] readBytesFromUri(Uri uri) throws IOException {
        InputStream inputStream = getContentResolver().openInputStream(uri);

        if (inputStream != null) {
            byte[] buffer = new byte[8192];
            ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
            int bytesRead;

            while ((bytesRead = inputStream.read(buffer)) != -1) {
                outputStream.write(buffer, 0, bytesRead);
            }

            inputStream.close();
            outputStream.close();

            return outputStream.toByteArray();
        }

        return new byte[0];
    }



    /*/@Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == STORAGE_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Permission Granted!",Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Permission Denied!",Toast.LENGTH_SHORT).show();
                finish();
            }
        }
    }/* */
}

