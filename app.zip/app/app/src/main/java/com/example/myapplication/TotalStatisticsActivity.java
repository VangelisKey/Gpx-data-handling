package com.example.myapplication;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.RadarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.RadarData;
import com.github.mikephil.charting.data.RadarDataSet;
import com.github.mikephil.charting.data.RadarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.util.ArrayList;

public class TotalStatisticsActivity extends AppCompatActivity {
    Handler handler;
    Button go_back;
    TextView user_distance;
    TextView user_time;
    TextView user_elevation;
    TextView average_distance;
    TextView average_time;
    TextView average_elevation;
    String[][] statistics;
    String user_name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_total_statistics);
        Intent intent = getIntent();
        if (intent != null && intent.hasExtra("STATISTICS")) {
            statistics = (String[][]) intent.getSerializableExtra("STATISTICS");
        }

        if (intent != null && intent.hasExtra("USERNAME")) {
            user_name = (String) intent.getSerializableExtra("USERNAME");
        }


        go_back = (Button) findViewById(R.id.button_go_back);
        user_distance = (TextView) findViewById(R.id.UserDistance);
        user_time = (TextView) findViewById(R.id.UserTime);
        user_elevation = (TextView) findViewById(R.id.UserElevation);

        average_distance = (TextView) findViewById(R.id.AverageDistance);
        average_time = (TextView) findViewById(R.id.AverageTime);
        average_elevation = (TextView) findViewById(R.id.AverageElevation);

        user_distance.setText(user_distance.getText()+" "+Math.round(Double.parseDouble(statistics[0][0])*100)/100.0+" Km");
        user_time.setText(user_time.getText()+" "+Math.round(Double.parseDouble(statistics[0][1])*100)/100.0+" s");
        user_elevation.setText(user_elevation.getText()+" "+Math.round(Double.parseDouble(statistics[0][2])*100)/100.0+" m");

        average_distance.setText(average_distance.getText()+" "+Math.round(Double.parseDouble(statistics[1][0])*100)/100.0+" Km");
        average_time.setText(average_time.getText()+" "+Math.round(Double.parseDouble(statistics[1][1])*100)/100.0+" s");
        average_elevation.setText(average_elevation.getText()+" "+Math.round(Double.parseDouble(statistics[1][2])*100)/100.0+" m");

        go_back.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                intent.putExtra("USERNAME",user_name);
                startActivity(intent);
            }
        });
        RadarChart radarChart = findViewById(R.id.radarChart);

        ArrayList<RadarEntry> userData = new ArrayList<>();
        userData.add(new RadarEntry(Float.parseFloat(statistics[1][0])*10));
        userData.add(new RadarEntry(Float.parseFloat(statistics[1][1])/60));
        userData.add(new RadarEntry(Float.parseFloat(statistics[1][2])));

        RadarDataSet radarUsers = new RadarDataSet(userData,"Average user");
        radarUsers.setColor(Color.RED);
        radarUsers.setLineWidth(2f);
        radarUsers.setValueTextColor(Color.RED);
        radarUsers.setValueTextSize(14f);

        ArrayList<RadarEntry> yourData = new ArrayList<>();
        yourData.add(new RadarEntry(Float.parseFloat(statistics[0][0])*10));
        yourData.add(new RadarEntry(Float.parseFloat(statistics[0][1])/60));
        yourData.add(new RadarEntry(Float.parseFloat(statistics[0][2])));

        RadarDataSet radarYou = new RadarDataSet(yourData,"You");
        radarYou.setColor(Color.YELLOW);
        radarYou.setLineWidth(2f);
        radarYou.setValueTextColor(Color.YELLOW);
        radarYou.setValueTextSize(14f);

        RadarData radarData = new RadarData();
        radarData.addDataSet(radarUsers);
        radarData.addDataSet(radarYou);

        String[] labels ={"Distance (100m)","Time (min)","Elevation (m)"};

        XAxis xAxis = radarChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));

        radarChart.setData(radarData);
        radarChart.getDescription().setText("You versus the average user");
    }
}
